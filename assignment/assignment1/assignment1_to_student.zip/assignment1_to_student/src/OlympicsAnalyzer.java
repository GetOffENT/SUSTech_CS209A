import java.util.*;

public class OlympicsAnalyzer implements OlympicsAnalyzerInterface {

    public OlympicsAnalyzer(String datasetPath) {

    }

    @Override
    public Map<String, Integer> topPerformantFemale() {
        return Map.of();
    }

    @Override
    public Map<String, Float> bmiBySports() {
        return Map.of();
    }

    @Override
    public Map<String, Set<Integer>> leastAppearedSport() {
        return Map.of();
    }

    @Override
    public Map<String, Integer> winterMedalsByCountry() {
        return Map.of();
    }

    @Override
    public Map<String, Integer> topCountryWithYoungAthletes() {
        return Map.of();
    }
}
