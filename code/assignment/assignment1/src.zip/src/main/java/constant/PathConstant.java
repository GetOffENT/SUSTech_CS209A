package constant;

/**
 * @author Will
 * @version 1.0
 * @Description: TODO
 * @Create: 2024-10-01 2:42
 */
public class PathConstant {
    public static final String OLYMPIC_ATHLETE_BIO_FILTERED = "/Olympic_Athlete_Bio_filtered.csv";
    public static final String OLYMPIC_ATHLETE_EVENT_RESULTS = "/Olympic_Athlete_Event_Results.csv";
    public static final String OLYMPIC_GAMES_MEDAL_TALLY = "/Olympic_Games_Medal_Tally.csv";
    public static final String OLYMPIC_RESULTS = "/Olympic_Results.csv";
    public static final String OLYMPICS_COUNTRY = "/Olympics_Country.csv";
    public static final String OLYMPICS_GAMES = "/Olympics_Games.csv";
}
