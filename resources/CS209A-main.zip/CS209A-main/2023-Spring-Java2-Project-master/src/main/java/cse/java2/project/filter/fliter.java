package cse.java2.project.filter;

public class fliter {
    public static final String fliter = "!*fL7K(WGWW-YgwNuYdMV-NhlpN89eFAUgH_A2";
}
